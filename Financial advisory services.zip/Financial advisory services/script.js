
function calculateLoan() {
  const amount = parseFloat(document.getElementById("loanAmount").value);
  const rate = parseFloat(document.getElementById("interestRate").value) / 100 / 12;
  const term = parseInt(document.getElementById("loanTerm").value) * 12;
  
  if (amount && rate && term) {
    const payment = (amount * rate) / (1 - Math.pow(1 + rate, -term));
    document.getElementById("result").innerText = `Monthly Payment: $${payment.toFixed(2)}`;
  } else {
    document.getElementById("result").innerText = "Please enter valid values.";
  }
}

// Form Validation
function validateForm() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const message = document.getElementById("message").value;

  if (name && email && message) {
    alert("Form submitted successfully!");
    return true;
  } else {
    alert("Please fill in all fields.");
    return false;
  }
}
